# documents/builders/invoice.py
from __future__ import annotations
from typing import Dict, Any, List
from sqlalchemy import text
from database.models import get_session_local
from decimal import Decimal
from documents.builders._shared import (
    blankify, coalesce, dedup_preserve_order, join_with_and,
    country_name   as _country_name,
    company_obj    as _company_obj,
    client_obj     as _client_obj,
    get_bank_info  as _get_bank_info,
    tafqit_amount  as _tafqit_amount,
    num_words      as _num_words,
    unit_word      as _unit_word,
    spell_non_monetary as _spell_non_monetary,
    label_from_pricing_code,
    compute_line_amount,
    currency_info  as _currency_info,
    delivery_method_name,
    pick_dest_col  as _pick_dest_col,
)
_blankify  = blankify
_coalesce  = coalesce
_dedup_preserve_order = dedup_preserve_order

# local helpers خاصة بـ invoice.py (تستخدم Decimal للدقة)
def _money(x) -> Decimal:
    return Decimal(str(x or "0")).quantize(Decimal("0.000"))

def _name(d: dict, lang: str) -> str:
    return (d or {}).get({"ar": "name_ar", "en": "name_en", "tr": "name_tr"}.get(lang, "name_en")) or ""

def _addr(d: dict, lang: str) -> str:
    key = {"ar": "address_ar", "en": "address_en", "tr": "address_tr"}.get(lang, "address_en")
    return (d or {}).get(key) or (d or {}).get("address") or ""

def _ensure(val, msg: str):
    if val in (None, "", 0):
        raise ValueError(msg)
    return val

def build_ctx(doc_code: str, transaction_id: int, lang: str) -> Dict[str, Any]:
    """
    يبني سياق الفاتورة (العادية/التجارية/البروفورما/السورية.*) بالاعتماد 100% على DB.
    لا افتراضات. أي نقص يرفع استثناء برسالة واضحة.
    """
    lang = (lang or "ar").lower()
    if lang not in ("ar","en","tr"):
        lang = "ar"

    SessionLocal = get_session_local()
    with SessionLocal() as s:
        # اكتشاف اسم عمود بلد الوجهة (يختلف بين إصدارات الـ schema)
        _tcols = {r["name"] for r in s.execute(text("PRAGMA table_info(transactions)")).mappings().all()}
        _dest_col = "destination_country_id" if "destination_country_id" in _tcols else "dest_country_id"

        # رأس المعاملة
        t = s.execute(text(f"""
            SELECT id,
                   COALESCE(transaction_no, CAST(id AS TEXT)) AS no,
                   transaction_date,
                   exporter_company_id, importer_company_id, client_id,
                   currency_id, delivery_method_id, transport_type, transport_ref,
                   origin_country_id, {_dest_col} AS destination_country_id,
                   notes
            FROM transactions WHERE id=:i
        """), {"i": int(transaction_id)}).mappings().first()
        if not t:
            raise ValueError("المعاملة غير موجودة.")

        # delivery_method اختياري — لا نوقف التوليد بسببه
        # currency_id: إن كان فارغاً سنأخذه من بنود المعاملة لاحقاً
        # transport_type/transport_ref اختياريان لكن يفضّل وجودهما
        # الدول: أصل/وجهة
        origin = s.execute(text("SELECT name_ar, name_en, name_tr FROM countries WHERE id=:id"),
                           {"id": t["origin_country_id"]}).mappings().first()
        dest = s.execute(text("SELECT name_ar, name_en, name_tr FROM countries WHERE id=:id"),
                         {"id": t["destination_country_id"]}).mappings().first()
        _ensure(origin, f"بلد المنشأ غير محدد في المعاملة {t['no']}.")
        _ensure(dest, f"بلد الوجهة غير محدد في المعاملة {t['no']}.")

        # العملة: من header أولاً، وإلا من بنود المعاملة (per-item currency)
        cur = None
        if t["currency_id"]:
            cur = s.execute(text("SELECT code, name_ar, name_en, name_tr FROM currencies WHERE id=:id"),
                            {"id": t["currency_id"]}).mappings().first()
        if not cur:
            cur_row = s.execute(text("""
                SELECT DISTINCT c.code, c.name_ar, c.name_en, c.name_tr
                FROM transaction_items ti
                JOIN currencies c ON c.id = ti.currency_id
                WHERE ti.transaction_id = :tid AND ti.currency_id IS NOT NULL
                LIMIT 1
            """), {"tid": int(transaction_id)}).mappings().first()
            if cur_row:
                cur = cur_row

        # طريقة التسليم: اختيارية
        dm = None
        if t["delivery_method_id"]:
            dm = s.execute(text("SELECT code, name_ar, name_en, name_tr FROM delivery_methods WHERE id=:id"),
                           {"id": t["delivery_method_id"]}).mappings().first()

        currency_code = cur["code"] if cur else ""
        delivery_method = _name(dm, lang) if dm else ""

        # الأطراف — نستخدم _company_obj لضمان وجود stamp_image وكل الحقول
        exp_obj = _company_obj(s, t["exporter_company_id"], lang) or {}
        _ensure(exp_obj.get("name") or exp_obj.get("id"), "شركة المصدّر غير موجودة.")

        # wrapper يحاكي الـ RowMapping القديم (name/address) مع إضافة stamp_image
        class _R(dict):
            def __getitem__(self, k): return self.get(k, "")

        exp = _R({
            "id":      exp_obj.get("id"),
            "name":    exp_obj.get("name", ""),
            "address": exp_obj.get("address", ""),
            "stamp_image": exp_obj.get("stamp_image", ""),
        })

        imp_obj = _company_obj(s, t["importer_company_id"], lang) or {}
        imp = _R({
            "id":      imp_obj.get("id"),
            "name":    imp_obj.get("name", ""),
            "address": imp_obj.get("address", ""),
            "stamp_image": imp_obj.get("stamp_image", ""),
        }) if imp_obj.get("id") else None

        cli = s.execute(text(f"SELECT id, name_{lang} AS name, COALESCE(address_{lang}, address) AS address FROM clients WHERE id=:id"),
                        {"id": t["client_id"]}).mappings().first()
        # بعض الفواتير قد تستخدم consignee = client
        consignee = cli or imp
        _ensure(consignee, "لا يوجد مستلم (client/importer).")

        # أسطر المعاملة
        rows = s.execute(text(f"""
            SELECT ti.id,
                   ti.quantity AS qty,
                   ti.net_weight_kg  AS net,
                   ti.gross_weight_kg AS gross,
                   pt.price_unit     AS unit_label,
                   m.name_{lang}     AS material,
                   pk.name_{lang}    AS packaging,
                   pt.code           AS pricing_code,
                   pt.name_{lang}    AS pricing_name,
                   ti.unit_price     AS unit_price
            FROM transaction_items ti
            JOIN materials m        ON m.id = ti.material_id
            LEFT JOIN packaging_types pk ON pk.id = ti.packaging_type_id
            LEFT JOIN pricing_types  pt ON pt.id = ti.pricing_type_id
            WHERE ti.transaction_id = :tid
            ORDER BY ti.id
        """), {"tid": int(transaction_id)}).mappings().all()
        if not rows:
            raise ValueError(f"لا توجد أسطر في المعاملة {t['no']}.")

        items: List[Dict[str, Any]] = []
        total_qty = Decimal("0")
        total_net = Decimal("0")
        total_gross = Decimal("0")
        total_value = Decimal("0")
        pricing_type_code = None
        pricing_type_name = None

        for r in rows:
            _ensure(r["packaging"], f"سطر {r['id']} بلا نوع تغليف (packaging_type).")
            _ensure(r["pricing_code"], f"سطر {r['id']} بلا نوع تسعير (pricing_type).")
            _ensure(r["unit_price"], f"سطر {r['id']} بلا سعر وحدة.")

            qty = Decimal(str(r["qty"] or "0"))
            net = Decimal(str(r["net"] or "0"))
            gross = Decimal(str(r["gross"] or "0"))
            price = Decimal(str(r["unit_price"] or "0"))
            amount = qty * price
            unit_label = (r["unit_label"] or "").strip() or None

            items.append({
                "no": r["id"],
                "description": r["material"],
                "packaging": r["packaging"],
                "qty": qty,
                "unit": unit_label,
                "net_kg": net,
                "gross_kg": gross,
                "unit_price": _money(price),
                "amount": _money(amount),
            })

            total_qty   += qty
            total_net   += net
            total_gross += gross
            total_value += amount

            pricing_type_code = pricing_type_code or r["pricing_code"]
            pricing_type_name = pricing_type_name or r["pricing_name"]

        # تفقيط (اختياري إن كانت الخدمة مجهزة)
        amount_in_words = ""
        try:
            from services.tafqit_service import tafqit_amount as _tafqit_svc
            amount_in_words = _tafqit_svc(total_value, currency_code, lang)
        except Exception:
            # لا افتراضات نصية؛ نتركها فارغة إذا الخدمة غير متوفرة
            amount_in_words = ""

        exp_bank = _get_bank_info(s, t["exporter_company_id"])
        ctx: Dict[str, Any] = {
            "title": None,  # العنوان من القالب
            "date": t["transaction_date"],
            "exporter": {"name": exp["name"], "addr": exp["address"],
                         "bank_info": exp_bank,
                         "stamp_image": exp.get("stamp_image", "")},
            "exp": {"name": exp["name"], "addr": exp["address"],
                    "bank_info": exp_bank,
                    "stamp_image": exp.get("stamp_image", "")},
            "bank_info": exp_bank,
            "consignee": {"name": consignee["name"], "addr": consignee["address"]},
            "importer": {"name": imp["name"], "addr": imp["address"],
                         "stamp_image": imp.get("stamp_image", "") if imp else ""} if imp else None,
            "shipment": {
                "delivery_method": delivery_method,
                "transport_type": t["transport_type"],
                "transport_ref": t["transport_ref"],
                "origin_country": _name(origin, lang),
                "destination": _name(dest, lang),
                "currency": currency_code,
            },
            "items": items,
            "totals": {"qty": total_qty, "gross": total_gross, "net": total_net, "value": _money(total_value)},
            "amount_in_words": amount_in_words,
            "pricing_type": {"code": pricing_type_code, "name": pricing_type_name},
            "currency": {"code": currency_code, "name": _name(cur, lang)},
            "notes": t.get("notes"),
        }
        return ctx