"""
Dashboard, Profile, and Notification Styles - LOGIPORT v3.1
=============================================================

Styles for:
- DashboardTab (stat cards, panels, header)
- UserProfileTab (hero, info rows, stat mini)
- NotificationPopup / bell
"""

from ..border_radius import BorderRadius


def get_styles(theme):
    c = theme.colors
    s = theme.sizes

    return f"""
    /* ===== DASHBOARD ===== */

    QWidget#dashboard-container {{
        background: {c["bg_main"]};
    }}

    QLabel#dashboard-title {{
        color: {c["text_primary"]};
        background: transparent;
    }}

    QLabel#text-muted {{
        color: {c["text_muted"]};
        background: transparent;
    }}

    /* ===== PROFILE ===== */

    QWidget#user-profile-tab {{
        background: {c["bg_main"]};
    }}

    QWidget#profile-container {{
        background: {c["bg_main"]};
    }}

    QLabel#section-title-lbl {{
        color: {c["text_primary"]};
        background: transparent;
    }}

    QFrame#separator {{
        background: {c["border_subtle"]};
        max-height: 1px;
        border: none;
    }}

    QLabel#info-label {{
        color: {c["text_secondary"]};
        background: transparent;
    }}

    QLabel#info-value {{
        color: {c["text_primary"]};
        background: transparent;
    }}

    /* ===== NOTIFICATION POPUP ===== */

    QFrame#notif-popup {{
        background: {c["bg_card"]};
        border: 1px solid {c["border"]};
        border-radius: {BorderRadius.XL};
    }}

    QFrame#notif-header {{
        background: transparent;
        border-bottom: 1px solid {c["border_subtle"]};
    }}

    /* btn-warning / btn-danger — defined in buttons.py */

    /* ===== DASHBOARD HEADER ===== */

    QWidget#dashboard-header-bar {{
        background: transparent;
    }}

    QLabel#panel-title {{
        color: {c["text_primary"]};
        font-weight: 700;
        background: transparent;
    }}

    /* ===== ACTIVITIES ===== */

    QWidget#activities-container {{
        background: transparent;
    }}

    QFrame#activity-item {{
        background: {c["bg_surface_2"]};
        border-radius: 8px;
        border: none;
    }}

    QFrame#activity-item:hover {{
        background: {c["bg_surface_1"]};
        border-left: 2px solid #C9A84C;
    }}

    QLabel#activity-msg {{
        color: {c["text_primary"]};
        background: transparent;
    }}

    QLabel#activity-ts {{
        color: {c["text_muted"]};
        background: transparent;
    }}

    /* ===== TRANSACTIONS TABLE ===== */

    QTableWidget#data-table {{
        background: {c["bg_card"]};
        border: none;
        gridline-color: transparent;
        alternate-background-color: {c["bg_surface_2"]};
        selection-background-color: rgba(201,168,76,0.12);
        selection-color: {c["text_primary"]};
        outline: none;
        font-size: {s["base"]}px;
    }}

    QTableWidget#data-table::item {{
        padding: 6px 10px;
        border: none;
    }}

    QTableWidget#data-table QHeaderView::section {{
        background: #0D1B2A;
        color: rgba(201, 168, 76, 0.9);
        font-weight: 700;
        font-size: {s["sm"]}px;
        padding: 8px 10px;
        border: none;
    }}

    /* ── Selection Action Bar ──────────────────────────────────────────── */
    QFrame#selection-action-bar {{
        background: {c["primary_light"]};
        border: 1px solid {c["primary"]};
        border-radius: 6px;
        min-height: 36px;
    }}

    QLabel#sel-count-label {{
        color: {c["primary"]};
        font-weight: 700;
        font-size: {s["md"]}px;
    }}

    /* Checkbox في header الجدول */
    QCheckBox#header-check-all {{
        spacing: 0px;
    }}

    QCheckBox#row-checkbox {{
        spacing: 0px;
    }}

    /* صف محدد — لون مميز */
    QTableWidget#data-table::item:selected {{
        background: {c["primary_light"]};
        color: {c["text_primary"]};
    }}

    /* ===== KPI CARDS — مُتحكم بها من dashboard_tab.py مباشرة ===== */
    /* لا نضع style هنا — كل KpiCard تتحكم بنفسها عبر _apply_theme() */

    /* ===== TYPE PROGRESS ROW ===== */

    QFrame#type-progress-row {{
        background: transparent;
        border: none;
    }}

    /* ===== TASKS STRIP ===== */

    QFrame#tasks-strip {{
        background: {c["bg_card"]};
        border-radius: 7px;
        border: 1px solid {c["border"]};
    }}

    /* ===== HERO BANNER ===== */

    QFrame#hero-banner {{
        background: #0D1B2A;
        border-radius: 12px;
        border: none;
    }}

    """