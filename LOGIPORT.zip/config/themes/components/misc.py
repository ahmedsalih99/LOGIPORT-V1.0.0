"""
Miscellaneous Component Styles
===============================

Scrollbar and other misc UI elements with modern gradients.
"""

from ..spacing import Spacing
from ..border_radius import BorderRadius


def get_styles(theme):
    """Generate miscellaneous styles"""
    c = theme.colors
    s = theme.sizes

    return f"""
    /* ========== SCROLLBAR - MODERN WITH GRADIENT ========== */

    /* Vertical Scrollbar */
    QScrollBar:vertical {{
        background: {c["bg_main"]};
        width: 8px;
        border-radius: 4px;
        margin: 0;
    }}

    QScrollBar::handle:vertical {{
        background: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 0,
            stop: 0 {c["primary"]},
            stop: 1 {c["primary_hover"]}
        );
        border-radius: 4px;
        min-height: 24px;
    }}

    QScrollBar::handle:vertical:hover {{
        background: {c["primary_hover"]};
    }}

    QScrollBar::add-line:vertical, 
    QScrollBar::sub-line:vertical {{
        height: 0px;
    }}

    QScrollBar::add-page:vertical, 
    QScrollBar::sub-page:vertical {{
        background: none;
    }}

    /* Horizontal Scrollbar */
    QScrollBar:horizontal {{
        background: {c["bg_main"]};
        height: 8px;
        border-radius: 4px;
        margin: 0;
    }}

    QScrollBar::handle:horizontal {{
        background: qlineargradient(
            x1: 0, y1: 0, x2: 0, y2: 1,
            stop: 0 {c["primary"]},
            stop: 1 {c["primary_hover"]}
        );
        border-radius: 6px;
        min-width: 30px;
    }}

    QScrollBar::handle:horizontal:hover {{
        background: {c["primary_hover"]};
    }}

    QScrollBar::add-line:horizontal, 
    QScrollBar::sub-line:horizontal {{
        width: 0px;
    }}

    /* ========== QMENU - CONTEXT MENU & DROPDOWNS ========== */

    QMenu {{
        background-color : {c["bg_card"]};
        color            : {c["text_primary"]};
        border           : 1px solid {c["border"]};
        border-radius    : 10px;
        padding          : 6px 4px;
        font-size        : {s["base"]}px;
        font-weight      : 500;
    }}

    QMenu::item {{
        padding          : 9px 20px 9px 16px;
        border-radius: {BorderRadius.MD};
        margin           : 2px 4px;
        min-width        : 160px;
        color            : {c["text_primary"]};
    }}

    QMenu::item:selected {{
        background-color : {c["bg_hover"]};
        color            : {c["primary"]};
    }}

    QMenu::item:pressed {{
        background-color : {c["bg_active"]};
        color            : {c["primary_active"]};
    }}

    QMenu::item:disabled {{
        color            : {c["text_disabled"]};
        background-color : transparent;
    }}

    QMenu::separator {{
        height           : 1px;
        background       : {c["border_subtle"]};
        margin           : 4px 12px;
    }}

    QMenu::indicator {{
        width            : 16px;
        height           : 16px;
    }}

    /* ========== QCOMBOBOX DROPDOWN ========== */

    QAbstractItemView {{
        background-color : {c["bg_card"]};
        color            : {c["text_primary"]};
        border           : 1px solid {c["border"]};
        border-radius    : 8px;
        padding          : 4px;
        outline          : none;
        selection-background-color: {c["primary_light"]};
        selection-color  : {c["primary"]};
    }}

    QAbstractItemView::item {{
        padding          : 8px 12px;
        border-radius    : 6px;
        min-height       : 34px;
        color            : {c["text_primary"]};
    }}

    QAbstractItemView::item:hover {{
        background-color : {c["bg_hover"]};
        color            : {c["primary"]};
    }}

    QAbstractItemView::item:selected {{
        background-color : {c["primary_light"]};
        color            : {c["primary"]};
        font-weight      : 600;
    }}

    /* ========== FILTER BAR ========== */

    QWidget#filter-bar {{
        background   : {c["bg_card"]};
        border       : none;
        border-bottom: 1px solid {c["border_subtle"]};
        border-radius: 0;
        padding      : 2px 0;
    }}

    QWidget#filter-group {{
        background   : {c["bg_main"]};
        border       : 1.5px solid {c["border"]};
        border-radius: {BorderRadius.MD};
    }}

    QPushButton#filter-preset-btn {{
        background   : transparent;
        border       : 1.5px solid {c["border"]};
        border-radius: {BorderRadius.MD};
        padding      : 0 12px;
        font-size    : {s["sm"]}px;
        color        : {c["text_secondary"]};
        min-height   : 30px;
        font-weight  : 500;
    }}
    QPushButton#filter-preset-btn:hover {{
        background   : {c["primary_light"]};
        border-color : {c["primary"]};
        color        : {c["primary"]};
    }}
    QPushButton#filter-preset-btn:checked {{
        background   : {c["primary"]};
        border-color : {c["primary"]};
        color        : #FFFFFF;
        font-weight  : 700;
    }}

    QPushButton#filter-clear-btn {{
        background    : transparent;
        border        : 1.5px solid {c["danger"]}50;
        border-radius : {BorderRadius.MD};
        font-size     : {s["sm"]}px;
        color         : {c["danger"]};
        min-width     : 30px;
        max-width     : 30px;
        min-height    : 30px;
        max-height    : 30px;
        padding       : 0;
    }}
    QPushButton#filter-clear-btn:hover {{
        background   : {c["danger"]}12;
        border-color : {c["danger"]};
    }}

    QFrame#filter-sep {{
        color     : {c["border"]};
        max-width : 1px;
        min-width : 1px;
    }}

    QLabel#filter-count-lbl {{
        color     : {c["text_muted"]};
        font-size : {s["sm"]}px;
        padding   : 0 4px;
    }}
    /* ========== SEMANTIC LABELS ========== */
    QLabel#text-muted, QLabel#empty-label, QLabel#form-hint {{
        color        : {c["text_muted"]};
        background   : transparent;
    }}
    QLabel#text-secondary {{
        color        : {c["text_secondary"]};
        background   : transparent;
    }}
    QLabel#text-danger, QLabel#form-error {{
        color        : {c["danger"]};
        background   : transparent;
    }}
    QLabel#text-warning {{
        color        : {c["warning"]};
        background   : transparent;
    }}
    QLabel#text-success {{
        color        : {c["success"]};
        background   : transparent;
    }}
    QLabel#text-primary {{
        color        : {c["primary"]};
        background   : transparent;
    }}
    QLabel#preview-label {{
        background   : {c["bg_secondary"]};
        color        : {c["text_muted"]};
        border       : 1px solid {c["border"]};
        border-radius: 4px;
        padding      : 4px 8px;
    }}

    /* ========== QSplitter ========== */

    QSplitter::handle {{
        background  : {c["border_subtle"]};
    }}
    QSplitter::handle:horizontal {{
        width : 1px;
    }}
    QSplitter::handle:vertical {{
        height: 1px;
    }}
    QSplitter::handle:hover {{
        background: {c["primary_light"]};
    }}

    /* ========== QToolTip ========== */

    QToolTip {{
        background   : {c["bg_card"]};
        color        : {c["text_primary"]};
        border       : 1px solid {c["border"]};
        border-radius: 6px;
        padding      : 5px 10px;
        font-size    : {s["sm"]}px;
        font-weight  : 400;
    }}

    """