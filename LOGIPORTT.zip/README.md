<div dir="rtl">

<div align="center">

# 🚢 LOGIPORT
### نظام إدارة العمليات اللوجستية

[![Python](https://img.shields.io/badge/Python-3.10%20%7C%203.11-blue?logo=python)](https://python.org)
[![PySide6](https://img.shields.io/badge/UI-PySide6%20%2F%20Qt6-green)](https://doc.qt.io/qtforpython/)
[![SQLAlchemy](https://img.shields.io/badge/ORM-SQLAlchemy%202.0-red)](https://www.sqlalchemy.org/)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange)](version.py)

نظام سطح مكتب شامل لإدارة المعاملات اللوجستية — مواد، عملاء، فواتير، قوائم تعبئة

**العربية · English · Türkçe**

</div>

---

## ✨ المميزات الرئيسية

- **إدارة المعاملات** — استيراد / تصدير / ترانزيت مع ترقيم ذكي تلقائي
- **إدارة العملاء والشركات** — ملفات كاملة مع بيانات الاتصال
- **توليد المستندات** — فواتير وقوائم تعبئة بصيغ HTML و PDF
- **لوحة تحكم تحليلية** — إحصائيات فورية ورسوم بيانية
- **دعم متعدد اللغات** — عربي وإنجليزي وتركي مع دعم RTL كامل
- **نظام صلاحيات** — إدارة مستخدمين مع أدوار ومستويات وصول
- **وضع مظلم / فاتح** — ثيم احترافي مع تأثيرات زجاجية

---

## 🖥️ متطلبات التشغيل

| المتطلب | الإصدار |
|---------|---------|
| Python | 3.10 أو 3.11 |
| نظام التشغيل | Windows 10 / 11 |

---

## 🚀 التثبيت والتشغيل

```bash
# 1. انسخ المستودع
git clone https://github.com/ahmedsalih99/LOGIPORT-V1.0.0.git
cd LOGIPORT-V1.0.0

# 2. أنشئ بيئة افتراضية (اختياري لكن مُوصى به)
python -m venv venv
venv\Scripts\activate

# 3. ثبّت المكتبات
pip install -r requirements.txt

# 4. شغّل التطبيق
python main.py
```

### أول تشغيل
عند الفتح لأول مرة ستظهر **نافذة الإعداد الأولي** لإنشاء حساب المسؤول (Admin).

---

## 📄 ميزة توليد PDF

توليد PDF يتطلب تثبيت **GTK3 Runtime** على Windows:

👉 [تحميل GTK3 لـ Windows](https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer)

> بدون GTK3 يعمل التطبيق بشكل كامل ويمكن توليد HTML فقط بدلاً من PDF.

---

## 🗂️ هيكل المشروع

```
LOGIPORT/
├── main.py              # نقطة الدخول
├── version.py           # رقم الإصدار
├── requirements.txt     # المكتبات المطلوبة
├── config/              # إعدادات التطبيق
├── core/                # المنطق الأساسي
├── database/            # النماذج والـ CRUD
│   ├── models/
│   └── crud/
├── services/            # طبقة الخدمات
├── ui/                  # واجهة المستخدم (PySide6)
│   ├── components/
│   ├── dialogs/
│   └── windows/
├── documents/           # قوالب المستندات
├── utils/               # أدوات مساعدة
└── tests/               # اختبارات شاملة (590+)
```

---

## 🔧 التقنيات المستخدمة

| التقنية | الاستخدام |
|---------|-----------|
| PySide6 / Qt6 | واجهة المستخدم |
| SQLAlchemy 2.0 | قاعدة البيانات ORM |
| SQLite | قاعدة البيانات |
| Jinja2 | قوالب المستندات |
| WeasyPrint | توليد PDF |
| openpyxl | تصدير Excel |
| bcrypt | تشفير كلمات المرور |

---

## 📦 بيانات المستخدم

يحفظ التطبيق قاعدة البيانات والإعدادات في:
```
Windows: %APPDATA%\LOGIPORT\
```

---

<div align="center">
صُنع بـ ❤️ بواسطة <a href="https://github.com/ahmedsalih99">ahmedsalih99</a>
</div>

</div>
